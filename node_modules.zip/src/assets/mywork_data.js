import Portfolio_img from '../assets/portfolio_2.png'
import Course_Project from '../assets/little_lemon_img.png'


const mywork_data = [
    {
        w_no:1,
        w_name:"Portfolio",
        w_img:Portfolio_img
    },
    {
        w_no:2,
        w_name:"course_project",
        w_img:Course_Project
    }
]
export default mywork_data;